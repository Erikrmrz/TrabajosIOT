/*
 * bleprph + control del LED RGB (WS2812) del ESP32-C6-DevKitC-1
 * Basado en el ejemplo NimBLE bleprph de ESP-IDF 5.x
 *
 * Comandos que se escriben por BLE (1 byte):
 *   0x01 -> Azul | 0x02 -> Verde | 0x03 -> Rojo | otro -> Apagado
 */

#include "esp_log.h"
#include "nvs_flash.h"

/* BLE */
#include "nimble/nimble_port.h"
#include "nimble/nimble_port_freertos.h"
#include "host/ble_hs.h"
#include "host/util/util.h"
#include "services/gap/ble_svc_gap.h"
#include "bleprph.h"

/* LED RGB */
#include "led_strip.h"

#define BLINK_GPIO 8   // LED RGB integrado de la DevKitC-1

static const char *TAG = "BLEPRPH_LED";

static uint8_t own_addr_type;
static led_strip_handle_t led_strip;

void ble_store_config_init(void);
static int bleprph_gap_event(struct ble_gap_event *event, void *arg);

/* ------------------------------------------------------------------ */
/*                              LED RGB                               */
/* ------------------------------------------------------------------ */

void configurar_led(void)
{
    led_strip_config_t strip_config = {
        .strip_gpio_num = BLINK_GPIO,
        .max_leds = 1,
    };
    led_strip_rmt_config_t rmt_config = {
        .resolution_hz = 10 * 1000 * 1000,  // 10 MHz
    };
    ESP_ERROR_CHECK(led_strip_new_rmt_device(&strip_config, &rmt_config, &led_strip));
    led_strip_clear(led_strip);  // Inicia apagado
}

/* Sin "static": se llama desde gatt_svr.c */
void controlar_led_rgb(uint8_t comando)
{
    if (comando == 1) {
        led_strip_set_pixel(led_strip, 0, 0, 0, 50);   // Azul
        led_strip_refresh(led_strip);
    } else if (comando == 2) {
        led_strip_set_pixel(led_strip, 0, 0, 50, 0);   // Verde
        led_strip_refresh(led_strip);
    } else if (comando == 3) {
        led_strip_set_pixel(led_strip, 0, 50, 0, 0);   // Rojo
        led_strip_refresh(led_strip);
    } else {
        led_strip_clear(led_strip);                    // Apagado
    }
}

/* ------------------------------------------------------------------ */
/*                               BLE                                  */
/* ------------------------------------------------------------------ */

static void bleprph_print_conn_desc(struct ble_gap_conn_desc *desc)
{
    ESP_LOGI(TAG, "handle=%d our_ota_addr_type=%d our_ota_addr=",
             desc->conn_handle, desc->our_ota_addr.type);
    print_addr(desc->our_ota_addr.val);
    ESP_LOGI(TAG, "our_id_addr_type=%d our_id_addr=", desc->our_id_addr.type);
    print_addr(desc->our_id_addr.val);
    ESP_LOGI(TAG, "peer_ota_addr_type=%d peer_ota_addr=",
             desc->peer_ota_addr.type);
    print_addr(desc->peer_ota_addr.val);
    ESP_LOGI(TAG, "peer_id_addr_type=%d peer_id_addr=", desc->peer_id_addr.type);
    print_addr(desc->peer_id_addr.val);
    ESP_LOGI(TAG, "conn_itvl=%d conn_latency=%d supervision_timeout=%d "
             "encrypted=%d authenticated=%d bonded=%d",
             desc->conn_itvl, desc->conn_latency,
             desc->supervision_timeout,
             desc->sec_state.encrypted,
             desc->sec_state.authenticated,
             desc->sec_state.bonded);
}

#if CONFIG_BT_NIMBLE_EXT_ADV
/* Version con advertising extendido (se usa cuando EXT_ADV esta activo).
 * Se publica con PDU legacy para que cualquier celular lo detecte. */
static void bleprph_advertise(void)
{
    struct ble_gap_ext_adv_params params;
    struct os_mbuf *data;
    uint8_t adv_data[31];
    uint8_t len = 0;
    const uint8_t instance = 0;
    const char *name = ble_svc_gap_device_name();
    uint8_t name_len = strlen(name);
    int rc;

    if (ble_gap_ext_adv_active(instance)) {
        return;
    }

    memset(&params, 0, sizeof params);
    params.connectable = 1;
    params.scannable = 1;
    params.legacy_pdu = 1;
    params.own_addr_type = own_addr_type;
    params.primary_phy = BLE_HCI_LE_PHY_1M;
    params.secondary_phy = BLE_HCI_LE_PHY_1M;
    params.sid = 0;
    params.itvl_min = BLE_GAP_ADV_FAST_INTERVAL1_MIN;
    params.itvl_max = BLE_GAP_ADV_FAST_INTERVAL1_MAX;

    rc = ble_gap_ext_adv_configure(instance, &params, NULL,
                                   bleprph_gap_event, NULL);
    if (rc != 0) {
        ESP_LOGE(TAG, "error configurando ext adv; rc=%d", rc);
        return;
    }

    /* Datos: flags + nombre completo (maximo 31 bytes) */
    adv_data[len++] = 2;
    adv_data[len++] = BLE_HS_ADV_TYPE_FLAGS;
    adv_data[len++] = BLE_HS_ADV_F_DISC_GEN | BLE_HS_ADV_F_BREDR_UNSUP;
    if (name_len > sizeof(adv_data) - len - 2) {
        name_len = sizeof(adv_data) - len - 2;
    }
    adv_data[len++] = name_len + 1;
    adv_data[len++] = BLE_HS_ADV_TYPE_COMP_NAME;
    memcpy(&adv_data[len], name, name_len);
    len += name_len;

    data = os_msys_get_pkthdr(len, 0);
    if (data == NULL) {
        ESP_LOGE(TAG, "sin memoria para datos de advertising");
        return;
    }
    rc = os_mbuf_append(data, adv_data, len);
    if (rc != 0) {
        os_mbuf_free_chain(data);
        ESP_LOGE(TAG, "error armando datos de advertising; rc=%d", rc);
        return;
    }

    rc = ble_gap_ext_adv_set_data(instance, data);
    if (rc != 0) {
        ESP_LOGE(TAG, "error cargando datos de ext adv; rc=%d", rc);
        return;
    }

    rc = ble_gap_ext_adv_start(instance, 0, 0);
    if (rc != 0) {
        ESP_LOGE(TAG, "error iniciando ext adv; rc=%d", rc);
        return;
    }
    ESP_LOGI(TAG, "Advertising iniciado: %s", name);
}
#else
/* Inicia la publicidad (advertising) para que el celular vea el dispositivo */
static void bleprph_advertise(void)
{
    struct ble_gap_adv_params adv_params;
    struct ble_hs_adv_fields fields;
    const char *name;
    int rc;

    memset(&fields, 0, sizeof fields);

    fields.flags = BLE_HS_ADV_F_DISC_GEN | BLE_HS_ADV_F_BREDR_UNSUP;

    fields.tx_pwr_lvl_is_present = 1;
    fields.tx_pwr_lvl = BLE_HS_ADV_TX_PWR_LVL_AUTO;

    name = ble_svc_gap_device_name();
    fields.name = (uint8_t *)name;
    fields.name_len = strlen(name);
    fields.name_is_complete = 1;

    fields.uuids16 = (ble_uuid16_t[]) {
        BLE_UUID16_INIT(GATT_SVR_SVC_ALERT_UUID)
    };
    fields.num_uuids16 = 1;
    fields.uuids16_is_complete = 1;

    rc = ble_gap_adv_set_fields(&fields);
    if (rc != 0) {
        ESP_LOGE(TAG, "error configurando campos de advertising; rc=%d", rc);
        return;
    }

    memset(&adv_params, 0, sizeof adv_params);
    adv_params.conn_mode = BLE_GAP_CONN_MODE_UND;
    adv_params.disc_mode = BLE_GAP_DISC_MODE_GEN;
    rc = ble_gap_adv_start(own_addr_type, NULL, BLE_HS_FOREVER,
                           &adv_params, bleprph_gap_event, NULL);
    if (rc != 0) {
        ESP_LOGE(TAG, "error iniciando advertising; rc=%d", rc);
        return;
    }
}
#endif /* CONFIG_BT_NIMBLE_EXT_ADV */

/* Manejador de eventos de conexion */
static int bleprph_gap_event(struct ble_gap_event *event, void *arg)
{
    struct ble_gap_conn_desc desc;
    int rc;

    switch (event->type) {
    case BLE_GAP_EVENT_CONNECT:
        ESP_LOGI(TAG, "conexion %s; status=%d",
                 event->connect.status == 0 ? "establecida" : "fallida",
                 event->connect.status);
        if (event->connect.status == 0) {
            rc = ble_gap_conn_find(event->connect.conn_handle, &desc);
            assert(rc == 0);
            bleprph_print_conn_desc(&desc);
        }
        if (event->connect.status != 0) {
            /* Fallo la conexion: volver a publicitar */
            bleprph_advertise();
        }
        return 0;

    case BLE_GAP_EVENT_DISCONNECT:
        ESP_LOGI(TAG, "desconexion; reason=%d", event->disconnect.reason);
        bleprph_print_conn_desc(&event->disconnect.conn);
        bleprph_advertise();
        return 0;

    case BLE_GAP_EVENT_CONN_UPDATE:
        ESP_LOGI(TAG, "conexion actualizada; status=%d",
                 event->conn_update.status);
        rc = ble_gap_conn_find(event->conn_update.conn_handle, &desc);
        assert(rc == 0);
        bleprph_print_conn_desc(&desc);
        return 0;

    case BLE_GAP_EVENT_ADV_COMPLETE:
        ESP_LOGI(TAG, "advertising completo; reason=%d",
                 event->adv_complete.reason);
        bleprph_advertise();
        return 0;

    case BLE_GAP_EVENT_ENC_CHANGE:
        ESP_LOGI(TAG, "cifrado cambiado; status=%d",
                 event->enc_change.status);
        rc = ble_gap_conn_find(event->enc_change.conn_handle, &desc);
        assert(rc == 0);
        bleprph_print_conn_desc(&desc);
        return 0;

    case BLE_GAP_EVENT_SUBSCRIBE:
        ESP_LOGI(TAG, "suscripcion; conn_handle=%d attr_handle=%d reason=%d "
                 "prev_notify=%d cur_notify=%d prev_indicate=%d cur_indicate=%d",
                 event->subscribe.conn_handle,
                 event->subscribe.attr_handle,
                 event->subscribe.reason,
                 event->subscribe.prev_notify,
                 event->subscribe.cur_notify,
                 event->subscribe.prev_indicate,
                 event->subscribe.cur_indicate);
        return 0;

    case BLE_GAP_EVENT_MTU:
        ESP_LOGI(TAG, "MTU actualizado; conn_handle=%d cid=%d mtu=%d",
                 event->mtu.conn_handle,
                 event->mtu.channel_id,
                 event->mtu.value);
        return 0;

    case BLE_GAP_EVENT_REPEAT_PAIRING:
        /* Ya existe un bond con este dispositivo: borrarlo y emparejar de nuevo */
        rc = ble_gap_conn_find(event->repeat_pairing.conn_handle, &desc);
        assert(rc == 0);
        ble_store_util_delete_peer(&desc.peer_id_addr);
        return BLE_GAP_REPEAT_PAIRING_RETRY;

    case BLE_GAP_EVENT_PASSKEY_ACTION:
        ESP_LOGI(TAG, "PASSKEY_ACTION_EVENT; action=%d",
                 event->passkey.params.action);
        return 0;
    }

    return 0;
}

static void bleprph_on_reset(int reason)
{
    ESP_LOGE(TAG, "Reinicio forzado del host BLE; reason=%d", reason);
}

static void bleprph_on_sync(void)
{
    int rc;

    /* Asegura que haya una direccion de identidad */
    rc = ble_hs_util_ensure_addr(0);
    assert(rc == 0);

    /* Determina el tipo de direccion a usar */
    rc = ble_hs_id_infer_auto(0, &own_addr_type);
    if (rc != 0) {
        ESP_LOGE(TAG, "error determinando tipo de direccion; rc=%d", rc);
        return;
    }

    /* Imprime la direccion */
    uint8_t addr_val[6] = {0};
    rc = ble_hs_id_copy_addr(own_addr_type, addr_val, NULL);
    ESP_LOGI(TAG, "Direccion del dispositivo: ");
    print_addr(addr_val);

    /* Comienza a publicitar */
    bleprph_advertise();
}

void bleprph_host_task(void *param)
{
    ESP_LOGI(TAG, "Tarea del host BLE iniciada");
    nimble_port_run();   // No retorna hasta que se llame nimble_port_stop()
    nimble_port_freertos_deinit();
}

/* ------------------------------------------------------------------ */
/*                             app_main                               */
/* ------------------------------------------------------------------ */

void app_main(void)
{
    int rc;

    /* Inicializa el LED RGB */
    configurar_led();

    /* Inicializa NVS (guarda los bonds/emparejamientos) */
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES ||
        ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }
    ESP_ERROR_CHECK(ret);

    /* Inicializa el stack NimBLE */
    ret = nimble_port_init();
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Fallo al iniciar nimble; ret=%d", ret);
        return;
    }

    /* Configuracion del host BLE */
    ble_hs_cfg.reset_cb = bleprph_on_reset;
    ble_hs_cfg.sync_cb = bleprph_on_sync;
    ble_hs_cfg.gatts_register_cb = gatt_svr_register_cb;
    ble_hs_cfg.store_status_cb = ble_store_util_status_rr;

    /* Seguridad: emparejamiento "Just Works" con bonding */
    ble_hs_cfg.sm_io_cap = BLE_SM_IO_CAP_NO_IO;
    ble_hs_cfg.sm_bonding = 1;
    ble_hs_cfg.sm_mitm = 0;
    ble_hs_cfg.sm_sc = 1;
    ble_hs_cfg.sm_our_key_dist |= BLE_SM_PAIR_KEY_DIST_ENC | BLE_SM_PAIR_KEY_DIST_ID;
    ble_hs_cfg.sm_their_key_dist |= BLE_SM_PAIR_KEY_DIST_ENC | BLE_SM_PAIR_KEY_DIST_ID;

    /* Registra los servicios GATT (gatt_svr.c) */
    rc = gatt_svr_init();
    assert(rc == 0);

    /* Nombre con el que aparece en nRF Connect */
    rc = ble_svc_gap_device_name_set("nimble-bleprph");
    assert(rc == 0);

    /* Almacen de bonds en NVS */
    ble_store_config_init();

    /* Lanza la tarea del host BLE */
    nimble_port_freertos_init(bleprph_host_task);
}